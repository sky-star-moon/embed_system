#include <STC15F2K60S2.H>
#include "intrins.h"
#define myBirthday 0x19980219
char LED[10]={0x3f, 0x06, 0x5b, 0x4f,0x66, 0x6d, 0x7d, 0x07,0x7f, 0x6f};
unsigned long Number = myBirthday ;//+ 1000000000;
unsigned char num,length=10;
unsigned int num_high;
unsigned int num_mid;
unsigned int num_low;
char dis,i,x;
unsigned long temp;
char seg[10];
void set_digit(){
	char tempx;
	char n = 3;
	while(n--){
		 tempx= num_low % 10;
		seg[--length] = tempx;
		num_low /= 10;
	}
	n = 3;
	while(n--){
		tempx= num_mid % 10;
		seg[--length] = tempx;
		num_mid /= 10;
	}
	n = 3;
	while(n--){
		tempx= num_high % 10;
		seg[--length] = tempx;
		num_high /= 10;
	}
}

void Delay1000ms()		//@11.0592MHz
{
	unsigned char i, j, k;
	_nop_();
	_nop_();
	i = 43;
	j = 6;
	k = 203;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void sel_LED(char num)	      
{   
	P2=(P2&0xf0)|(0x0f&num); 
}

void init()	        
{
	P0M0=0xFF;
	P0M1=0x00;
  P2M0=0x0f;
	P2M1=0x00;
	sel_LED(0);
}

void main(){
	init();
	num_high = Number / 1000000;
	num_mid = (Number - num_high*1000000) / 1000;
	num_low = Number % 1000;
	set_digit();
	length=1;
	while(1){
		num = seg[length++];
		if(length == 10) 
			length =1;
		}
}



