#include <STC15F2K60S2.H>
#define uchar unsigned char
uchar i,j;
sbit LED1 = P0^1;
idata uchar STACK[20];
void task(void){
	j=0xff;
	i=0x01;
	while(j--);
	#pragma asm
	PUSH i;
	
	#pragma endasm
}
void main(){
	
	while(1){
		j=0xff;
		while(j--);
		SP=STACK;
		task();
		i=1;
	}
	
}